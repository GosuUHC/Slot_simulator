var count = 1;

var simg = document.getElementById('sound_img');

function playPause() {
  if(count==0){
    count=1;
    audio.pause();
    simg.src = "img/soundoff.png";

  }else{
    count=0;
    audio.play();
    simg.src = "img/soundon.png";

  }
}
var rolla = document.getElementById('rolled');

function playRoll() {
  rolla.play();
}



window.onload = function () {
    var audio = document.getElementById('audio');
    var sound_btn = document.getElementById('sound_img');
    sound_btn.onclick = function() {
        playPause();
    }


}
