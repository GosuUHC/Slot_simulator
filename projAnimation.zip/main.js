var deposit = 0;
var a,b,c;
const button = document.getElementById("btn_go");

var eventsbet = [];

var row_sym = document.getElementById("rs");
var cb = document.getElementById("cb");
var wrap = document.getElementById("wrap");
var starti = document.getElementById("start");
var res_text = document.getElementById("res_text");
var hbb = document.getElementById('hisbets_btn');
hbb.style.display = 'none';
row_sym.style.display = 'none';
cb.style.display = 'none';
wrap.style.backgroundImage = 'url(img/menu_start.jpg)';

function deposit_update(){
  document.getElementById("dep").innerHTML = deposit;
};

function exitBets() {
  document.getElementById("betshisdiv").remove();
  hbb.src = "img/betshistory.png";
  row_sym.style.display = 'block';
  cb.style.display = 'block';
  hbb.style.display = '';
  hbb.src = "img/betshistory.png";
  wrap.style.backgroundImage = 'url(img/menu.jpg)';
  deposit_update();
}

hbb.addEventListener('click', event => {
  if(wrap.style.backgroundImage == 'url("img/menu.jpg")'){
    showBets();
  }else{
    exitBets();
  }
});

function addCode() {


  document.getElementById("createbetsdiv").innerHTML +=
    "<div id='betshisdiv'><table id='betshistable'><tr><th id='betelementmain'>Event</th><th id='betelementmain'>Amount</th><th id='betelementmain'>Payout</th><th id='betelementmain'>Result</th></tr></table></div>";
  eventsbet.forEach(function (item,index,array) {

    function findEl() {
      var eltext = "";
      if(eventsbet[index][3] == "lose"){
        eventsbet[index].forEach(function (item,index,array){
          eltext += "<th id='betelementlose'>{elem}</th>".replace('{elem}', item);
        })
      }else if(eventsbet[index][3] == "win"){
        eventsbet[index].forEach(function (item,index,array){
          eltext += "<th id='betelementwin'>{elem}</th>".replace('{elem}', item);
        })
      }else{
        eventsbet[index].forEach(function (item,index,array){
          eltext += "<th id='betelement'>{elem}</th>".replace('{elem}', item);
        })
      }


      return eltext;
    }

    document.getElementById("betshistable").innerHTML +=
      "<tr>{el}</tr>".replace('{el}', findEl());

  })

}

function showBets() {
  row_sym.style.display = 'none';
  cb.style.display = 'none';
  wrap.style.backgroundImage = 'url(img/menu_bets.jpg)';
  addCode();
  hbb.src = "img/exit.png";
}

const pay_click = document.getElementById("dep_go");
pay_click.addEventListener('click', event => {
  pay_deposit();
});

function pay_deposit() {
  var input_dep = Math.round(document.getElementById("input_dep").value);
  if(parseInt(input_dep) && input_dep > 0){
    deposit = input_dep;
    eventsbet.unshift(['deposit', input_dep, '','']);
    starti.style.display = 'none';
    row_sym.style.display = 'block';
    cb.style.display = 'block';
    hbb.style.display = '';
    hbb.src = "img/betshistory.png";
    wrap.style.backgroundImage = 'url(img/menu.jpg)';
    deposit_update();
  }else{
    alert("Wrong deposit!");
  }
};


function animate_bets () {

  var bet_sum = document.getElementById("input_bet").value;
  if (parseInt(bet_sum)) {
    if(deposit>0 && bet_sum<=deposit && bet_sum>0){
      var r1,r2,r3;
      var image1 = document.getElementById("first");
      var image2 = document.getElementById("second");
      var image3 = document.getElementById("third");
      var repeat = setInterval(function(){
        r1 = Math.floor(Math.random() * 6) + 1;
        r2 = Math.floor(Math.random() * 6) + 1;
        r3 = Math.floor(Math.random() * 6) + 1;
        image1.src="img/{a}.png".replace('{a}', r1);
        image2.src="img/{a}.png".replace('{a}', r2);
        image3.src="img/{a}.png".replace('{a}', r3);
      }, 100)
      setTimeout(function(){
        clearInterval(repeat);
        bet();
      }, 2000)
    }else{
      alert("Zero deposit or wrong bet");
    }
  } else {
    alert("Enter the correct number!")
  }
}


button.addEventListener('click', event => {
  animate_bets();
});

function payout(y, bet_sum){
  deposit = deposit + bet_sum*y;
  document.getElementById("res_text").innerHTML = "You won {bet}!".replace('{bet}', bet_sum*y);
  res_text.style.color = 'green';
  eventsbet.unshift(['bet', bet_sum, bet_sum*y + " |" + "x{y}".replace('{y}', y) + "|",'win']);
}

function do_lose(y, bet_sum){
  deposit = deposit + bet_sum*y;
  document.getElementById("res_text").innerHTML = "You won {bet}!".replace('{bet}', bet_sum*y);
  res_text.style.color = 'green';
}

function bet_logic(a,b,c,bet_sum){
  if (a == b && a == c && b == c){
    if(a == 1){
      payout(7,bet_sum);
    }else if (a == 2) {
      payout(12,bet_sum);
    }else if (a == 3) {
      payout(20,bet_sum);
    }else if (a == 4) {
      payout(25,bet_sum);
    }else if (a == 5) {
      payout(30,bet_sum);
    }else if (a == 6) {
      payout(80,bet_sum);
    }
  } else if (a == b) {

    if(a == 1){
      payout(0.5,bet_sum);
    }else if (a == 2) {
      payout(2.5,bet_sum);
    }else if (a == 3) {
      payout(5,bet_sum);
    }else if (a == 4) {
      payout(7,bet_sum);
    }else if (a == 5) {
      payout(9,bet_sum);
    }else if (a == 6) {
      payout(12,bet_sum);
    }

  } else if (a == c){

    if(a == 1){
      payout(0.5,bet_sum);
    }else if (a == 2) {
      payout(2.5,bet_sum);
    }else if (a == 3) {
      payout(5,bet_sum);
    }else if (a == 4) {
      payout(7,bet_sum);
    }else if (a == 5) {
      payout(9,bet_sum);
    }else if (a == 6) {
      payout(12,bet_sum);
    }
  } else {
    document.getElementById("res_text").innerHTML = "You lose {bet}!".replace('{bet}', bet_sum);
    res_text.style.color = 'red';
    eventsbet.unshift(['bet', bet_sum, "-" + bet_sum ,'lose']);


  }
}

function second_random(){
  var x;
  x = Math.floor(Math.random() * 100);
  if (x <= 28){
   return(1);
  }else if(x <= 50 && x > 28 ){
   return(2);
  }else if(x > 50 && x <= 70 ){
   return(3);
  }else if(x <= 85 && x > 70 ){
   return(4);
  }else if(x <= 95 && x > 85 ){
   return(5);
  }else{
   return(6);
  }
}

function third_random(bet_sum,image1,image2,image3){

  var rpv1,rpv2,rpv3;
  rpv1 = Math.floor(Math.random() * 6)+1;
  image1.src="img/{a}.png".replace('{a}', rpv1);
  rpv2 = Math.floor(Math.random() * 6)+1;
  while (rpv2 == rpv1) {
    rpv2 = Math.floor(Math.random() * 6)+1;
  };
  image2.src="img/{a}.png".replace('{a}', rpv2);
  rpv3 = Math.floor(Math.random() * 6)+1;
  while (rpv3 == rpv2 || rpv3 == rpv1) {
    rpv3 = Math.floor(Math.random() * 6)+1;
  };
  image3.src="img/{a}.png".replace('{a}', rpv3);


  document.getElementById("res_text").innerHTML = "You lose {bet}!".replace('{bet}', bet_sum);
  res_text.style.color = 'red';
}

function bet() {
  var bet_sum = document.getElementById("input_bet").value;
  if (parseInt(bet_sum)) {
    if(deposit>0 && bet_sum<=deposit && bet_sum>0){
      deposit = deposit - bet_sum;
      deposit_update()
      var image1 = document.getElementById("first");
      var image2 = document.getElementById("second");
      var image3 = document.getElementById("third");

      //first_random
      var rp, rp1, rp2 ,rp3;
      rp = Math.floor(Math.random() * 100);

      if(rp>65){
        rp1 = second_random();
        rp2 = second_random();
        rp3 = second_random();

        image1.src="img/{a}.png".replace('{a}', rp1);
        image2.src="img/{a}.png".replace('{a}', rp2);
        image3.src="img/{a}.png".replace('{a}', rp3);
        a = rp1;
        b = rp2;
        c = rp3;
        bet_logic(a,b,c,bet_sum);
      }else{
        third_random(bet_sum,image1,image2,image3);
        eventsbet.unshift(['bet', bet_sum, "-" + bet_sum ,'lose']);
      }
      deposit_update()
    }else{
      alert("Zero deposit or wrong bet");
    }
  } else {
    alert("Enter the correct number!")
  }
  deposit_update();
}
